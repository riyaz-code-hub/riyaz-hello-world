
CREATE TABLE tbt_person(
id INT NOT NULL,
fname VARCHAR(50) NOT NULL,
lname VARCHAR(50) NOT NULL,
mail VARCHAR(50) NOT NULL,
mobile INT  NULL,
dob  DATE NULL
);