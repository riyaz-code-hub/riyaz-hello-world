
INSERT INTO tbt_person(id,fname,lname,mail,mobile)
values(1,'Riyaz', 'Alam','riyaz@gmail.com',988998);

INSERT INTO tbt_person(id,fname,lname,mail,mobile)
values(2,'Arkaan', 'Raza','arkaan@gmail.com',988998);

INSERT INTO tbt_person(id,fname,lname,mail,mobile)
values(3,'Arham', 'Raza','arham@gmail.com',12345);

